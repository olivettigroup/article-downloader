''' Settings file for ArticleDownloader '''

# File to run on data retrieved from APIs (IDs and PDFs)
after_script = 'settings/after_script.py'
